package kit.mdk0103.chemeris.lab03;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate(View view) {
        CheckBox checkBoxApple = findViewById(R.id.checkBoxApple);
        CheckBox checkBoxStrawberry = findViewById(R.id.checkBoxStrawberry);
        CheckBox checkBoxBlueBerry = findViewById(R.id.checkBoxBlueberry);
        CheckBox checkBoxPotatoes = findViewById(R.id.checkBoxPotato);

        EditText inputApple = findViewById(R.id.inputEditTextApple);
        EditText inputStrawberry = findViewById(R.id.inputEditTextStrawberry);
        EditText inputBlueberry = findViewById(R.id.inputEditTextBlueberry);
        EditText inputPotato = findViewById(R.id.inputEditTextPotato);

        EditText priceA = findViewById(R.id.inputEditTextPriceApple);
        EditText priceS = findViewById(R.id.inputEditTextPriceStrawberry);
        EditText priceB = findViewById(R.id.inputEditTextPriceBlueberry);
        EditText priceP = findViewById(R.id.inputEditTextPricePotato);

        RadioButton toast = findViewById(R.id.Toast);
        RadioButton dialog = findViewById(R.id.Dialog);

        double result = 0;

        if (checkBoxApple.isChecked()) {
            result += Double.parseDouble(inputApple.getText().toString()) * Double.parseDouble(priceA.getText().toString());
        }
        if (checkBoxStrawberry.isChecked()) {
            result += Double.parseDouble(inputStrawberry.getText().toString()) * Double.parseDouble(priceS.getText().toString());
        }
        if (checkBoxBlueBerry.isChecked()) {
            result += Double.parseDouble(inputBlueberry.getText().toString()) * Double.parseDouble(priceB.getText().toString());
        }
        if (checkBoxPotatoes.isChecked()) {
            result += Double.parseDouble(inputPotato.getText().toString()) * Double.parseDouble(priceP.getText().toString());
        }

        if (toast.isChecked()) {
            Toast.makeText(this, "Total price is " + result + "$", Toast.LENGTH_LONG).show();
        }
        if (dialog.isChecked()){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Total Price");
            builder.setMessage("Total price is " + result + "$");
            builder.setCancelable(true);
            builder.show();
        }
    }
}